package dms.gui;

import dms.model.Movie;
import dms.service.MovieManager;

import javax.swing.*;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.awt.*;
import java.io.File;
import java.time.Year;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.OptionalDouble;

/**
 * Main GUI window for the Movie Manager DMS (Phase 3 - GUI).
 * Allows the user to perform CRUD operations and custom actions
 * using a friendly graphical interface.
 */
public class MovieManagerGUI extends JFrame {
    private final MovieManager mgr = new MovieManager();
    private final MovieTableModel tableModel = new MovieTableModel(mgr);
    private final JTable table = new JTable(tableModel);

    public MovieManagerGUI() {
        super("Movie Manager DMS (Phase 3 - GUI)");
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setMinimumSize(new Dimension(980, 600));
        setLocationRelativeTo(null);

        setJMenuBar(buildMenuBar());
        add(buildToolbar(), BorderLayout.NORTH);
        add(new JScrollPane(table), BorderLayout.CENTER);
        add(buildStatusBar(), BorderLayout.SOUTH);
    }

    /** Builds the top menu bar with all main options. */
    private JMenuBar buildMenuBar() {
        JMenuBar mb = new JMenuBar();

        // --- File menu ---
        JMenu file = new JMenu("File");
        JMenuItem open = new JMenuItem("Load CSV...");
        open.addActionListener(e -> onLoadCsv());
        JMenuItem paste = new JMenuItem("Paste CSV...");
        paste.addActionListener(e -> onPasteCsv());
        JMenuItem exit = new JMenuItem("Exit");
        exit.addActionListener(e -> onExit());
        file.add(open);
        file.add(paste);
        file.addSeparator();
        file.add(exit);

        // --- Data menu ---
        JMenu data = new JMenu("Data");
        JMenuItem show = new JMenuItem("Display All");
        show.addActionListener(e -> refreshTable());
        JMenuItem add = new JMenuItem("Add...");
        add.addActionListener(e -> onAdd());
        JMenuItem edit = new JMenuItem("Edit...");
        edit.addActionListener(e -> onEdit());
        JMenuItem del = new JMenuItem("Delete");
        del.addActionListener(e -> onDelete());
        data.add(show);
        data.addSeparator();
        data.add(add);
        data.add(edit);
        data.add(del);

        // --- Custom action menu ---
        JMenu calc = new JMenu("Actions");
        JMenuItem avg = new JMenuItem("Average Duration");
        avg.addActionListener(e -> onAverage());
        calc.add(avg);

        // --- Help menu ---
        JMenu help = new JMenu("Help");
        JMenuItem about = new JMenuItem("About...");
        about.addActionListener(e -> Dialogs.info(this,
                "Movie Manager DMS\nPhase 3 (GUI, no database)\n© " +
                        Year.now().getValue() + " Luis A. Monserratt"));
        help.add(about);

        mb.add(file);
        mb.add(data);
        mb.add(calc);
        mb.add(help);
        return mb;
    }

    /** Builds the top toolbar with quick action buttons. */
    private JToolBar buildToolbar() {
        JToolBar tb = new JToolBar();
        tb.setFloatable(false);

        JButton btnOpen = new JButton("Load CSV");
        btnOpen.addActionListener(e -> onLoadCsv());

        JButton btnShow = new JButton("Show All");
        btnShow.addActionListener(e -> refreshTable());

        JButton btnAdd = new JButton("Add");
        btnAdd.addActionListener(e -> onAdd());

        JButton btnEdit = new JButton("Edit");
        btnEdit.addActionListener(e -> onEdit());

        JButton btnDel = new JButton("Delete");
        btnDel.addActionListener(e -> onDelete());

        JButton btnAvg = new JButton("Average");
        btnAvg.addActionListener(e -> onAverage());

        tb.add(btnOpen);
        tb.add(btnShow);
        tb.addSeparator();
        tb.add(btnAdd);
        tb.add(btnEdit);
        tb.add(btnDel);
        tb.addSeparator();
        tb.add(btnAvg);
        return tb;
    }

    /** Creates a small status bar that displays messages and record count. */
    private JPanel buildStatusBar() {
        JPanel p = new JPanel(new BorderLayout());
        p.setBorder(BorderFactory.createEmptyBorder(4, 8, 4, 8));
        JLabel left = new JLabel("Ready");
        JLabel right = new JLabel("Records: 0");
        p.add(left, BorderLayout.WEST);
        p.add(right, BorderLayout.EAST);

        // Update counter after each refresh
        tableModel.setOnAfterRefresh(() -> right.setText("Records: " + tableModel.getRowCount()));
        return p;
    }

    /** Loads movies from a CSV file chosen by the user. */
    private void onLoadCsv() {
        JFileChooser fc = new JFileChooser();
        fc.setDialogTitle("Select CSV file");
        fc.setFileFilter(new FileNameExtensionFilter("CSV files", "csv"));
        int r = fc.showOpenDialog(this);
        if (r != JFileChooser.APPROVE_OPTION) return;

        File f = fc.getSelectedFile();
        var rep = mgr.loadCsv(f.getAbsolutePath());
        Dialogs.info(this, rep.summary() +
                (rep.errors.isEmpty() ? "" : "\n\nErrors:\n- " + String.join("\n- ", rep.errors)));
        refreshTable();
    }

    /** Allows the user to paste raw CSV lines directly into a text area. */
    private void onPasteCsv() {
        JTextArea ta = new JTextArea(12, 60);
        ta.setLineWrap(true);
        ta.setWrapStyleWord(true);
        int ok = JOptionPane.showConfirmDialog(this, new JScrollPane(ta),
                "Paste CSV lines (id,title,director,year,duration,genre,rating)",
                JOptionPane.OK_CANCEL_OPTION);
        if (ok != JOptionPane.OK_OPTION) return;

        try {
            // Save pasted content into a temp file and reuse the same loader
            File tmp = File.createTempFile("movies_paste_", ".csv");
            java.nio.file.Files.writeString(tmp.toPath(), ta.getText());
            var rep = mgr.loadCsv(tmp.getAbsolutePath());
            tmp.deleteOnExit();
            Dialogs.info(this, rep.summary() +
                    (rep.errors.isEmpty() ? "" : "\n\nErrors:\n- " + String.join("\n- ", rep.errors)));
            refreshTable();
        } catch (Exception ex) {
            Dialogs.error(this, "Unexpected error: " + ex.getMessage());
        }
    }

    /** Opens a dialog for manually adding a new movie. */
    private void onAdd() {
        MovieFormDialog dlg = new MovieFormDialog(this, "Add Movie", null, mgr);
        Movie m = dlg.showDialog();
        if (m != null) {
            boolean ok = mgr.add(m);
            if (!ok) {
                Dialogs.error(this, "Failed to add movie. Check duplicates or validation errors.");
            } else {
                refreshTable();
            }
        }
    }

    /** Opens a dialog to edit the selected movie. */
    private void onEdit() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Dialogs.warn(this, "Please select a row first.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        var opt = mgr.findById(id);
        if (opt.isEmpty()) {
            Dialogs.error(this, "Movie not found.");
            return;
        }
        Movie current = opt.get();
        MovieFormDialog dlg = new MovieFormDialog(this, "Edit Movie (" + id + ")", current, mgr);
        Movie edited = dlg.showDialog();
        if (edited != null) {
            // Build a map of updated fields to apply them selectively
            Map<String, String> fields = new LinkedHashMap<>();
            if (!edited.getTitle().equals(current.getTitle())) fields.put("title", edited.getTitle());
            if (!edited.getDirector().equals(current.getDirector())) fields.put("director", edited.getDirector());
            if (edited.getYear() != current.getYear()) fields.put("year", String.valueOf(edited.getYear()));
            if (Double.compare(edited.getDurationMinutes(), current.getDurationMinutes()) != 0)
                fields.put("duration", String.valueOf(edited.getDurationMinutes()));
            if (!edited.getGenre().equals(current.getGenre())) fields.put("genre", edited.getGenre());
            if (Double.compare(edited.getRating(), current.getRating()) != 0)
                fields.put("rating", String.valueOf(edited.getRating()));

            boolean ok = fields.isEmpty() || mgr.updateFields(id, fields);
            if (!ok) {
                Dialogs.error(this, "Update failed (validation error).");
            } else {
                refreshTable();
            }
        }
    }

    /** Deletes the currently selected movie. */
    private void onDelete() {
        int row = table.getSelectedRow();
        if (row < 0) {
            Dialogs.warn(this, "Please select a row first.");
            return;
        }
        String id = (String) tableModel.getValueAt(row, 0);
        if (!Dialogs.confirm(this, "Delete record with ID: " + id + "?")) return;

        boolean ok = mgr.remove(id);
        if (!ok) Dialogs.error(this, "Deletion failed (movie not found).");
        refreshTable();
    }

    /** Displays the average movie duration (custom action). */
    private void onAverage() {
        OptionalDouble avg = mgr.averageDuration();
        String msg = avg.isPresent()
                ? String.format("Average duration: %.2f min", avg.getAsDouble())
                : "No movies currently in the system.";
        Dialogs.info(this, msg);
    }

    /** Closes the program safely with confirmation. */
    private void onExit() {
        if (Dialogs.confirm(this, "Exit the program?")) {
            dispose();
            System.exit(0);
        }
    }

    /** Reloads data from the MovieManager into the table model. */
    private void refreshTable() {
        tableModel.refresh();
    }
}
