package dms.gui;

import dms.model.Movie;
import dms.service.MovieManager;

import javax.swing.table.AbstractTableModel;
import java.util.List;

/**
 * Custom table model for displaying Movie objects in a JTable.
 * Retrieves data directly from the MovieManager service.
 */
public class MovieTableModel extends AbstractTableModel {
    private final MovieManager mgr;
    private List<Movie> cache;
    private Runnable onAfterRefresh;

    private final String[] cols = {
            "MovieID", "Title", "Director", "Year", "Duration (min)", "Genre", "Rating"
    };

    public MovieTableModel(MovieManager mgr) {
        this.mgr = mgr;
        refresh();
    }

    /** Sets a callback that executes after each refresh. */
    public void setOnAfterRefresh(Runnable r) { this.onAfterRefresh = r; }

    /** Refreshes the table content using the current movie list. */
    public void refresh() {
        this.cache = mgr.all(); // unmodifiable list from MovieManager
        fireTableDataChanged();
        if (onAfterRefresh != null) onAfterRefresh.run();
    }

    @Override public int getRowCount() { return cache == null ? 0 : cache.size(); }
    @Override public int getColumnCount() { return cols.length; }
    @Override public String getColumnName(int column) { return cols[column]; }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex) {
        Movie m = cache.get(rowIndex);
        return switch (columnIndex) {
            case 0 -> m.getMovieID();
            case 1 -> m.getTitle();
            case 2 -> m.getDirector();
            case 3 -> m.getYear();
            case 4 -> m.getDurationMinutes();
            case 5 -> m.getGenre();
            case 6 -> m.getRating();
            default -> "";
        };
    }

    @Override
    public Class<?> getColumnClass(int columnIndex) {
        return switch (columnIndex) {
            case 3 -> Integer.class;
            case 4, 6 -> Double.class;
            default -> String.class;
        };
    }

    @Override
    public boolean isCellEditable(int rowIndex, int columnIndex) {
        return false; // Editing is handled via dialog for better validation
    }
}
