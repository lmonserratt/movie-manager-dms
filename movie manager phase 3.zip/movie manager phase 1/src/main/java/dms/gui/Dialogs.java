package dms.gui;

import javax.swing.*;
import java.awt.*;

/**
 * Utility class for showing consistent dialog boxes
 * (information, warning, error, and confirmation).
 */
public class Dialogs {

    /** Shows an information dialog. */
    public static void info(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Information", JOptionPane.INFORMATION_MESSAGE);
    }

    /** Shows a warning dialog. */
    public static void warn(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Warning", JOptionPane.WARNING_MESSAGE);
    }

    /** Shows an error dialog. */
    public static void error(Component parent, String msg) {
        JOptionPane.showMessageDialog(parent, msg, "Error", JOptionPane.ERROR_MESSAGE);
    }

    /** Shows a confirmation dialog and returns true if the user clicks YES. */
    public static boolean confirm(Component parent, String msg) {
        return JOptionPane.showConfirmDialog(parent, msg, "Confirm",
                JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION;
    }
}
