package dms.gui;

import javax.swing.*;

/**
 * Entry point for the Movie Manager GUI application (Phase 3).
 * Initializes the system look & feel and launches the main window.
 */
public class GuiMain {
    public static void main(String[] args) {
        // Apply the native OS Look & Feel for better appearance
        try {
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (Exception ignored) {}

        // Run GUI on the Event Dispatch Thread
        SwingUtilities.invokeLater(() -> {
            MovieManagerGUI win = new MovieManagerGUI();
            win.setVisible(true);
        });
    }
}
