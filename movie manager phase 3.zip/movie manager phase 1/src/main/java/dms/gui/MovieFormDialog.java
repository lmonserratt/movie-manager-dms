package dms.gui;

import dms.model.Movie;
import dms.service.MovieManager;

import javax.swing.*;
import java.awt.*;
import java.time.Year;

/**
 * Dialog for adding or editing a Movie object.
 * Performs user input validation before creating/updating the record.
 */
public class MovieFormDialog extends JDialog {
    private final JTextField tfId = new JTextField(12);
    private final JTextField tfTitle = new JTextField(24);
    private final JTextField tfDirector = new JTextField(24);
    private final JTextField tfYear = new JTextField(6);
    private final JTextField tfDur = new JTextField(8);
    private final JTextField tfGenre = new JTextField(16);
    private final JTextField tfRating = new JTextField(6);

    private Movie result;        // null if canceled
    private final Movie existing; // not null if editing
    private final MovieManager mgr;

    public MovieFormDialog(Frame owner, String title, Movie existing, MovieManager mgr) {
        super(owner, title, true);
        this.existing = existing;
        this.mgr = mgr;

        setLayout(new BorderLayout(12, 12));
        JPanel form = new JPanel(new GridLayout(0, 2, 8, 8));
        form.setBorder(BorderFactory.createEmptyBorder(12, 12, 0, 12));

        form.add(new JLabel("MovieID:"));
        form.add(tfId);
        form.add(new JLabel("Title:"));
        form.add(tfTitle);
        form.add(new JLabel("Director:"));
        form.add(tfDirector);
        form.add(new JLabel("Year (1888.." + (Year.now().getValue() + 1) + "):"));
        form.add(tfYear);
        form.add(new JLabel("Duration (min) > 0:"));
        form.add(tfDur);
        form.add(new JLabel("Genre:"));
        form.add(tfGenre);
        form.add(new JLabel("Rating (1..10):"));
        form.add(tfRating);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        JButton ok = new JButton("Save");
        JButton cancel = new JButton("Cancel");
        buttons.add(cancel);
        buttons.add(ok);

        add(form, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        pack();
        setLocationRelativeTo(owner);

        // Fill form for editing mode
        if (existing != null) {
            tfId.setText(existing.getMovieID());
            tfId.setEnabled(false); // ID cannot be edited
            tfTitle.setText(existing.getTitle());
            tfDirector.setText(existing.getDirector());
            tfYear.setText(String.valueOf(existing.getYear()));
            tfDur.setText(String.valueOf(existing.getDurationMinutes()));
            tfGenre.setText(existing.getGenre());
            tfRating.setText(String.valueOf(existing.getRating()));
        } else {
            tfId.setEnabled(false); // Auto-generate ID for new record
        }

        cancel.addActionListener(e -> { result = null; dispose(); });
        ok.addActionListener(e -> onSave());
        getRootPane().setDefaultButton(ok);
    }

    /** Shows the dialog and returns the created/edited movie, or null if canceled. */
    public Movie showDialog() {
        setVisible(true);
        return result;
    }

    /** Validates all fields and builds a new Movie object if valid. */
    private void onSave() {
        // --- Title ---
        String title = tfTitle.getText().trim();
        if (title.isEmpty()) { Dialogs.warn(this, "Title is required."); return; }

        // --- Director ---
        String director = tfDirector.getText().trim();
        if (director.isEmpty()) { Dialogs.warn(this, "Director is required."); return; }

        // --- Year ---
        int currentMaxYear = Year.now().getValue() + 1;
        int year;
        try {
            year = Integer.parseInt(tfYear.getText().trim());
            if (year < 1888 || year > currentMaxYear) throw new IllegalArgumentException();
        } catch (Exception ex) {
            Dialogs.warn(this, "Invalid year (1888.." + currentMaxYear + ").");
            return;
        }

        // --- Duration ---
        double dur;
        try {
            dur = Double.parseDouble(tfDur.getText().trim());
            if (dur <= 0) throw new IllegalArgumentException();
        } catch (Exception ex) {
            Dialogs.warn(this, "Duration must be greater than 0.");
            return;
        }

        // --- Genre ---
        String genre = tfGenre.getText().trim();
        if (genre.isEmpty()) { Dialogs.warn(this, "Genre is required."); return; }

        // --- Rating ---
        double rating;
        try {
            rating = Double.parseDouble(tfRating.getText().trim());
            if (rating < 1.0 || rating > 10.0) throw new IllegalArgumentException();
        } catch (Exception ex) {
            Dialogs.warn(this, "Invalid rating (1..10).");
            return;
        }

        // --- ID ---
        String id;
        if (existing != null) {
            id = existing.getMovieID();
        } else {
            id = mgr.generateID(title, year);
            tfId.setText(id);
        }

        Movie m = new Movie(id, title, director, year, dur, genre, rating);
        var errs = m.validate();
        if (!errs.isEmpty()) {
            Dialogs.error(this, "Validation errors:\n- " + String.join("\n- ", errs));
            return;
        }

        result = m;
        dispose();
    }
}
